class Sorter {
  constructor() {
    // your implementation
  }

  add(element) {
    // your implementation
  }

  at(index) {
    // your implementation
  }

  get length() {
    // your implementation
  }

  toArray() {
    // your implementation
  }

  sort(indices) {
    // your implementation
  }

  setComparator(compareFunction) {
    // your implementation
  }
}

module.exports = Sorter;